<?php

	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASSWORD", "");
	define("DB", "e-projet");
	define("ROOT_DIR", "localhost/e-Projet/");

?>