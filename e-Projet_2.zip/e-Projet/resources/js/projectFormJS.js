
// everytime the user put a ";" character, the format of the textarea is changed
$('#proj_obj').keyup(function(touche){
	
	var appui = touche.which || touche.keyCode;
	if (appui == 59 || appui == 13){
		var obj_content = $(this).html();
		var obj_tab = obj_content.split(";")
		var obj_content = "";
		for (var i = 0; i < obj_tab.length; i++){
			obj_content += '<a href="#">'+obj_tab[i]+'</a>';
		}
		alert(obj_content);
		$(this).val(obj_content);
	}
	
});