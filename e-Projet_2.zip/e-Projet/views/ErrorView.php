<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Titre</title>
	</head>
	<body>
		<?php echo $ok ?>
	</body>
</html>