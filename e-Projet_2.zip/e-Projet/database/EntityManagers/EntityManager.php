<?php

abstract class EntityManager
{

	// Properties
	private $connection;
}
